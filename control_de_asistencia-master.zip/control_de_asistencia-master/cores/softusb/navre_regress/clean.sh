#!/bin/sh
rm -f modules/*.pyc
rm -f test_opcodes/*.pyc
rm -f flash.rom gpr.rom spr.rom sram.rom verilog.log
